import asyncio
import logging
import os.path
import sqlite3
from datetime import datetime, timedelta

import aiogram
from aiogram.utils.exceptions import WrongFileIdentifier
from googletrans import Translator
from random import Random

import configparser
import requests
import fake_useragent
from aiogram.types import InputFile
from asyncpg import Path
from bs4 import BeautifulSoup, Tag
from loader import bot
import re

music_bot_id = '@test1221212'
news_bot_id = '@NewChePostOfficial'
pornaphorism = '@test1221212'
caption_music = str()


def get_fake_user_agent():
    user = fake_useragent.UserAgent().random
    header = {
        'user-agent': user
    }
    return header


def get_music():
    music_list = {'hip-hop-rap': 2, 'dance': 3, 'latin': 8, 'afrobeats': 11, 'worldwide': 12,
                  'reggae-dancehall': 13,
                  'house': 14}
    for item in music_list:
        res = requests.get(f"https://www.shazam.com/shazam/v3/ru/UA/web/-/"
                           f"tracks/genre-global-chart-{music_list[item]}?pageSize=200&startFrom=0",
                           headers=get_fake_user_agent()).json()

        for title in res["tracks"]:
            with open('handlers/users/list_of_parsing/music.txt', 'a', encoding='utf-8') as f:
                f.write(f"{title['title']} - {title['subtitle']}\n")


def get_book():
    i = 0
    for book in range(2000):
        if i >= 20:
            break
        res = requests.get(f"https://t.me/bydlo_book/{book}",
                           headers=get_fake_user_agent()).text
        soup = BeautifulSoup(res, 'lxml')
        x = soup.find('meta', property="og:description").get('content')
        if str(x).startswith("Обзоры книг от души душевно в душу.") or str(x) is None:
            i += 1
        else:
            i = 0
            with open('handlers/users/list_of_parsing/books.txt', 'a', encoding='utf-8') as f:
                f.write(f"{x}\n")


async def sent_music_to_channel(del_lines, download_mp3, title, image):
    with open('handlers/users/list_of_parsing/music.txt', 'r', encoding='utf-8') as f:
        lines = f.readlines()

    with open('handlers/users/list_of_parsing/music.txt', 'w', encoding='utf-8') as f:
        f.writelines(lines[del_lines:])

    await bot.send_audio(chat_id=music_bot_id, audio=download_mp3, caption=caption_music,
                         title=title, thumb=image)


async def sent_books_to_channel(del_lines, download_fb2, title, text, author, image):
    pass
    # with open('handlers/users/list_of_parsing/books.txt', 'r', encoding='utf-8') as f:
    #     lines = f.readlines()
    #
    # with open('handlers/users/list_of_parsing/books.txt', 'w', encoding='utf-8') as f:
    #     f.writelines(lines[del_lines:])
    # if len(text) > 900:
    #     t = '12'
    # else:
    #     t = text
    # # await bot.send_document(chat_id=music_bot_id,
    # #                         thumb=image,
    # #                         caption=f"Книга: <b>#{title}</b>\n"
    # #                                 f"Автор: <b>#{author}</b>\n"
    # #                                 # f"\n {text}", document=InputFile(path_or_bytesio=download_fb2))
    # #                                 f"\n {t}", document=download_fb2)
    # await bot.send_document(chat_id=music_bot_id,
    #                         thumb=image,
    #                         caption=f"123", document=download_fb2)


async def music_parsing():
    try:
        if os.path.exists("handlers/users/list_of_parsing/music.txt") is False or \
                os.stat("handlers/users/list_of_parsing/music.txt").st_size == 0:
            get_music()
        with open("handlers/users/list_of_parsing/music.txt", encoding='utf-8') as f:
            music_list = f.read().splitlines()
        del_lines = 0
        for track in music_list:
            search = requests.get(f"https://ru-music.com/search/{track}",
                                  headers=get_fake_user_agent()).text
            soup = BeautifulSoup(search, 'lxml')
            li = soup.find('li', class_='track')
            if li is None:
                search = requests.get(f"https://pesni.cc/search/{track}", headers=get_fake_user_agent()).text
                soup = BeautifulSoup(search, 'lxml')
                link = soup.find('a', class_='playlist-down')
                if link is None:
                    continue
                link = link.get('href')
                search = requests.get(f"https://pesni.cc{link}", headers=get_fake_user_agent()).text
                soup = BeautifulSoup(search, 'lxml')
                url = soup.find('a', class_='onesongblock-play no-ajax __adv_stream').get('data-urlsong')
                download_mp3 = requests.get(url, headers=get_fake_user_agent()).content
                del_lines = del_lines + 1
                image = requests.get("https://cameralabs.org/media/lab18/03/02/arhiv-muzykalnyh-oblozhek_5.jpg").content
                del_lines = del_lines + 1
                await sent_music_to_channel(del_lines, download_mp3, track, image)
                break
            if li:
                title = (li.find('div', class_='cover_image')).find('img').get('alt')
                image = (li.find('div', class_='cover_image')).find('img').get('src')
                image = requests.get(image, headers=get_fake_user_agent()).content
                download_mp3 = requests.get(f"https://dl6.ru-music.cc/mp3/{li.get('data-id')}.mp3",
                                            headers=get_fake_user_agent()).content

                del_lines = del_lines + 1
                await sent_music_to_channel(del_lines, download_mp3, title, image)
                break
            else:
                del_lines = del_lines + 1
                continue
    except Exception as e:
        print(e)


async def library_parsing():
    try:
        if os.path.exists("handlers/users/list_of_parsing/books.txt") is False or \
                os.stat("handlers/users/list_of_parsing/books.txt").st_size == 0:
            get_book()
        with open("handlers/users/list_of_parsing/books.txt", encoding='utf-8') as f:
            books_list = f.read().splitlines()
        search = requests.get(f"http://flibusta.is/booksearch?ask={books_list[0]}",
                              headers=get_fake_user_agent()).text
        print("search")
        soup = BeautifulSoup(search, 'lxml')
        li = ((soup.find('div', id='main-wrapper')).find_all("li"))[1]
        print(li)
        book_href = str(li).split("\"")[1]
        print("book_href")
        search = requests.get(f"http://flibusta.is/{book_href}",
                              headers=get_fake_user_agent()).text
        # fb2 = requests.get(f"https://tululu.org/zip.php?id=46168",
        #                    headers=get_fake_user_agent()).url
        fb2_url = requests.get(f"http://flibusta.is/{book_href}/fb2",
                               headers=get_fake_user_agent()).url
        fb2 = requests.get(fb2_url,
                           headers=get_fake_user_agent()).content

        # fb2 = requests.get(f"https://www.uscis.gov/sites/default/files/document/forms/i-9-paper-version.pdf",
        #                    headers=get_fake_user_agent()).content
        soup = BeautifulSoup(search, 'lxml')
        book_fb2 = soup.find('div', id='main')
        author = re.sub("<.*?>", "", (str(li).split("\"")[-1])[1:])
        print(author)
        text = re.sub("<.*?>", "", str(book_fb2.find_all("p")[1]))
        image = book_fb2.find("img", alt="Cover image")
        image = image.get('src')
        print(image)
        image_bytes = requests.get(f"http://flibusta.is/{image}",
                                   headers=get_fake_user_agent()).content

        print(len(text))
        await sent_books_to_channel(del_lines=1, download_fb2=fb2, text=text, title=books_list[0], author=author,
                                    image=image_bytes)
    except Exception as e:
        logging.info(e)


async def gifs_parsing():
    pass


async def memes_parsing():
    pass


async def porn_quotes_parsing():
    page_photo = 1
    page_aphorism = 1
    PHOTO = 0
    APHORISM = 0
    try:
        while True:
            html_photo = BeautifulSoup(requests.get(url=f'https://ero.motaen.com/'
                                                        f'categories/view/page/{page_photo}/name/erotica',
                                                    headers=get_fake_user_agent()).text, 'lxml')

            href_photo: list[Tag] = html_photo.find("ul", class_='element').find_all("a")
            hrefs_photos = [href.get("href") for href in href_photo if href.get("title") is not None]

            html_aphorism = BeautifulSoup(requests.get(url=f'https://ru.citaty.net/'
                                                           f'tsitaty-o-zhenshchinakh/?page={page_aphorism}',
                                                       headers=get_fake_user_agent()).text, 'lxml')
            href_aphorism: list[Tag] = html_aphorism.find_all("article", class_='quote')
            hrefs_aphorism = [href.find("p", class_="blockquote-text").text for href in href_aphorism]
            hrefs_aphorism_authors = [href.find("p", class_="blockquote-origin").text for href in href_aphorism]
            print(len(hrefs_aphorism), len(hrefs_aphorism_authors), len(hrefs_photos))
            while PHOTO < 18:
                try:
                    html2_photo = BeautifulSoup(requests.get(url=f'https://ero.motaen.com{hrefs_photos[PHOTO]}',
                                                             headers=get_fake_user_agent()).text, 'lxml')

                    href2_photo = html2_photo.find("div", class_="desk-img").find("img").get("src")

                    await bot.send_photo(chat_id=pornaphorism, photo=f'https://ero.motaen.com{href2_photo}',
                                         caption=f'<i>{hrefs_aphorism[APHORISM]}</i>\n\n<b>{hrefs_aphorism_authors[APHORISM]}</b>')

                    PHOTO = PHOTO + 1
                    if hrefs_photos[PHOTO] == hrefs_photos[-1]:
                        PHOTO = 0
                        page_photo = page_photo + 1
                    if hrefs_aphorism[APHORISM] == hrefs_aphorism[-1]:
                        page_aphorism = page_aphorism + 1
                except Exception as e:
                    await bot.send_message(chat_id='617710378', text=f"erotics {e}")
                    PHOTO = PHOTO + 1
                    continue
                await asyncio.sleep(5)

    except Exception as e:
        await bot.send_message(chat_id='617710378', text=f"erotics {e}")


async def porn_videos_parsing():
    pass


async def news_parsing():
    # кожні 5 хв.
    try:
        site = "https://gordonua.com/tags/vojna-v-ukraine.html"
        request = requests.get(url=site, headers=get_fake_user_agent()).text
        html = BeautifulSoup(request, 'lxml')
        article = html.find("div", class_="lenta").find("a").get("href")
        news_site = requests.get(url=f"https://gordonua.com/{article}").text

        html = BeautifulSoup(news_site, 'lxml')
        news = html.find("div", class_="block article")
        h1 = news.find("h1", class_='a_head flipboard-title').text
        h2 = news.find("h2", class_="newposiziwin flipboard-subtitle").text
        # div: list[Tag] = news.find_all("div", class_="a_body newposiziwin")
        # p = [tag.text for tag in div]
        image = news.find("div", class_="span-8").find("img").get("src")
        print(image)
        img = requests.get(url=f"https://gordonua.com{image}", headers=get_fake_user_agent()).content

        with open('handlers/users/list_of_parsing/news.txt', 'r', encoding='utf-8') as f:
            lines = f.readlines()

        if h1 != lines[0]:
            with open('handlers/users/list_of_parsing/news.txt', 'w', encoding='utf-8') as f:
                f.writelines(h1)

            await bot.send_photo(photo=img, caption=f"⚡️<a href='https://gordonua.com/{article}'><b>{h1}</b></a>"
                                                    f"\n\n💬 <i>{h2}</i>",
                                 chat_id=news_bot_id)

    except Exception as e:
        await bot.send_message(chat_id="617710378", text=f'Новину не опубліковано, причина: {e}')


async def politics_parsing():
    pass


async def science_parsing():
    pass


async def marvel_dc_geek_parsing():
    pass


async def android_parsing():
    pass


async def hackers_parsing():
    translator = Translator()
    # кожну хв.

    try:
        site = "https://thehackernews.com/"
        request = requests.get(url=site, headers=get_fake_user_agent()).text
        html = BeautifulSoup(request, 'lxml')
        article = html.find("a", class_="story-link").get("href")
        html = BeautifulSoup(requests.get(url=article, headers=get_fake_user_agent()).text, 'lxml')  # ссилка в url
        caption = translator.translate(html.find("h1", class_="story-title").text, src='en', dest='ru').text

        h2 = translator.translate(html.find("div", class_="articlebody clear cf").find("p").text, src='en',
                                  dest='ru').text

        image = html.find("div", class_='separator').find("img").get("src")

        img = requests.get(url=image, headers=get_fake_user_agent()).content

        with open('handlers/users/list_of_parsing/hack.txt', 'r', encoding='utf-8') as f:
            lines = f.readlines()

        if caption == lines[0]:
            with open('handlers/users/list_of_parsing/hack.txt', 'w', encoding='utf-8') as f:
                f.writelines(caption)

            await bot.send_photo(photo=img, caption=f"⚡️<b>{caption}</b>\n\n💬 <i>{h2}</i>",
                                 chat_id=news_bot_id)

    except Exception as e:
        await bot.send_message(chat_id="617710378", text=f'Новину не опубліковано, причина: {e}')


async def estetic_parsing():
    pass


async def chernivtsi_news():
    def get_href(html: BeautifulSoup, tag: str, additional=None, **kwargs) -> str:
        if additional:
            return html.find(tag, **kwargs).find(additional).get("href")
        else:
            return html.find(tag, **kwargs).get("href")

    def convert_text(header: str, message: str, link: str) -> str:
        return f"<b><a href='{link}'>⚡{header.lstrip()}</a></b>\n\n<i>💬{message.lstrip()}</i>"

    def get_link(original_link: str, link_from_parsing: str) -> str:
        if link_from_parsing.startswith("https") or link_from_parsing.startswith("http"):
            return link_from_parsing
        elif link_from_parsing.find(original_link.removeprefix('https://')) != -1 \
                or link_from_parsing.find(original_link.removeprefix('http://')) != -1:
            return f"https:{link_from_parsing}"
        elif link_from_parsing.startswith("/"):
            return f"{original_link[:-1]}{link_from_parsing}"
        else:
            raise Exception

    def get_text(html: BeautifulSoup, tag: str, additional: str = None, **kwargs) -> str:
        if additional:
            return html.find(tag, **kwargs).find(additional).text
        else:
            return html.find(tag, **kwargs).text

    def get_img_link(html: BeautifulSoup, tag: str, link: str, additional: str = None, **kwargs) -> str:
        if additional:
            return get_link(original_link=link,
                            link_from_parsing=html.find(tag, **kwargs).find(additional).get("src"))
        else:
            return get_link(original_link=link, link_from_parsing=html.find(tag, **kwargs).get("src"))

    def read_config():
        config_file = configparser.ConfigParser()
        List_ALL = []
        config_file.read("configurations.ini")

        all_section = config_file.sections()
        for section in all_section:
            List_ALL.append(config_file.items(section))

        return List_ALL

    conn = sqlite3.connect("mydatabase.db", timeout=10)  # или :memory: чтобы сохранить в RAM
    cursor = conn.cursor()

    # Создание таблицы
    cursor.execute("""CREATE TABLE IF NOT EXISTS news
                      (header text, date_d text)
                   """)
    cursor.execute(f"""Delete from news where date_d='{datetime.today() - timedelta(days=3)}'
                      """)
    sites = read_config()
    for site in sites:
        try:
            html_menu = BeautifulSoup(requests.get(url=(site[0])[1], headers=get_fake_user_agent()).text, 'lxml')
            class_ = {(site[2])[1]: (site[3])[1]}
            if (site[4])[1] == '':
                href = get_href(html_menu, tag=(site[1])[1], **class_)
            else:
                href = get_href(html=html_menu, additional=(site[4])[1], tag=(site[1])[1], **class_)
            link = get_link(original_link=(site[0])[1], link_from_parsing=href)
            html_page = BeautifulSoup(requests.get(url=link, headers=get_fake_user_agent()).text, 'lxml')
            if (site[8])[1] == '':
                header = get_text(html_page, tag=(site[5])[1], **{(site[6])[1]: (site[7])[1]})
            else:
                header = get_text(html_page, additional=(site[8])[1], tag=(site[5])[1], **{(site[6])[1]: (site[7])[1]})

            if cursor.execute(f"SELECT * FROM news WHERE header=\'{header}\'").fetchone() is None:
                if (site[12])[1] == '':
                    message = get_text(html_page, tag=(site[9])[1], **{(site[10])[1]: (site[11])[1]})
                else:
                    message = get_text(html_page, additional=(site[12])[1], tag=(site[9])[1], **{(site[10])[1]: (site[11])[1]})

                if (site[13])[1] == 'True':
                    if (site[17])[1] == '':
                        img = get_img_link(html_page, link=(site[0])[1], tag=(site[14])[1], **{(site[15])[1]: (site[16])[1]})
                    else:
                        img = get_img_link(html_page, link=(site[0])[1], additional=(site[17])[1], tag=(site[14])[1],
                                           **{(site[15])[1]: (site[16])[1]})

                    await bot.send_photo(chat_id=news_bot_id, photo=img,
                                         caption=convert_text(header=header, message=message, link=link))
                else:
                    await bot.send_message(chat_id=news_bot_id, text=convert_text(header=header, message=message, link=link))
                cursor.execute(f"INSERT INTO news VALUES (?,?)", (header, datetime.today()))
                conn.commit()
                await asyncio.sleep(Random().randint(a=30, b=60))
        except WrongFileIdentifier:
            await bot.send_message(chat_id=news_bot_id, text=convert_text(header=header, message=message, link=link))
            cursor.execute(f"INSERT INTO news VALUES (?,?)", (header, datetime.today()))
            conn.commit()
        except Exception as e:
            await bot.send_message(chat_id="617710378", text=f'Новину в канал Чернівців з ссилкою {link} не \n'
                                                             f'{header}\n'
                                                             f'{message}\n'
                                                             f'опубліковано, причина: {e}')
            continue

    # acc, bukpravda, molbuk, \
    # promin, tva, pogliad, \
    # bukinfo, bukovyna, buknews = [BeautifulSoup(requests.get(url=site, headers=get_fake_user_agent()).text, 'lxml')
    #                               # promin, tva, pogliad, cvnews, \
    #                               for site in ["https://acc.cv.ua/", "http://bukpravda.cv.ua/", "https://molbuk.ua/",
    #                                            "https://promin.cv.ua/news/", "https://tva.ua/news-archive/",
    #                                            # "https://pogliad.ua/", "https://cvnews.cv.ua/Section/archive",
    #                                            "https://pogliad.ua/",
    #                                            "https://bukinfo.com.ua/", "https://bukovyna.online/",
    #                                            "https://buknews.com.ua/"]]
    #
    # acc_news = acc.find("a", class_="ColumnItem__desc").get("href")
    # bukpravda_news = bukpravda.find("a", class_="moduleItemTitle").get("href")
    # molbuk_news = molbuk.find("div", class_="dayNews-text").find("a").get("href")
    # promin_news = promin.find("h2", class_="short_title").find("a").get("href")
    # tva_news = tva.find("h2", class_="entry-post-title").find("a").get("href")
    # pogliad_news = pogliad.find("a", class_="article block importance-1").get("href")
    # # cvnews_news = cvnews.find("div", class_="col-lg-10 col-md-10").find("a").get("href")
    # bukinfo_news = bukinfo.find("div", class_="ni-info").find("a").get("href")
    # bukovyna_news = bukovyna.find("h4", class_="entry-title title").find("a").get("href")
    # buknews_news: list[Tag] = buknews.find_all("div", class_="news-item-title")
    # buknews_news = buknews_news[1].find("a").get("href")
    #
    # acc_link = f"https:{acc_news}"
    # bukpravda_link = f"http://bukpravda.cv.ua{bukpravda_news}"
    # molbuk_link = f"https://molbuk.ua/{molbuk_news}"
    # promin_link = f"{promin_news}"
    # tva_link = f"{tva_news}"
    # pogliad_link = f"https:{pogliad_news}"
    # # cvnews_link = f"{cvnews_news}"
    # bukinfo_link = f"{bukinfo_news}"
    # bukovyna_link = f"{bukovyna_news}"
    # buknews_link = f"https://buknews.com.ua{buknews_news}"
    #
    # acc_news_html = BeautifulSoup(requests.get(url=acc_link, headers=get_fake_user_agent()).text, 'lxml')
    # bukpravda_news_html = BeautifulSoup(requests.get(url=bukpravda_link,
    #                                                  headers=get_fake_user_agent()).text, 'lxml')
    # molbuk_news_html = BeautifulSoup(requests.get(url=molbuk_link,
    #                                               headers=get_fake_user_agent()).text, 'lxml')
    # promin_news_html = BeautifulSoup(requests.get(url=promin_link,
    #                                               headers=get_fake_user_agent()).text, 'lxml')
    # tva_news_html = BeautifulSoup(requests.get(url=tva_link,
    #                                            headers=get_fake_user_agent()).text, 'lxml')
    # pogliad_news_html = BeautifulSoup(requests.get(url=pogliad_link,
    #                                                headers=get_fake_user_agent()).text, 'lxml')
    # # cvnews_news_html = BeautifulSoup(requests.get(url=cvnews_link,
    # #                                               headers=get_fake_user_agent()).text, 'lxml')
    # bukinfo_news_html = BeautifulSoup(requests.get(url=bukinfo_link,
    #                                                headers=get_fake_user_agent()).text, 'lxml')
    # bukovyna_news_html = BeautifulSoup(requests.get(url=bukovyna_link,
    #                                                 headers=get_fake_user_agent()).text, 'lxml')
    # buknews_news_html = BeautifulSoup(requests.get(url=buknews_link,
    #                                                headers=get_fake_user_agent()).text, 'lxml')
    #
    # acc_news_h1 = acc_news_html.find("h1", class_='News__title').text
    # bukpravda_news_h1 = bukpravda_news_html.find("h2", class_='itemTitle').text
    # molbuk_news_h1 = molbuk_news_html.find("div", class_='short-block').find("h1").text
    # promin_news_h1 = promin_news_html.find("h1", class_="post_title").text
    # tva_news_h1 = tva_news_html.find("h2", class_='entry-title').text
    # pogliad_news_h1 = pogliad_news_html.find("h1", class_='article-heading').text
    # # cvnews_news_h1 = cvnews_news_html.find("h1", class_='title').text
    # bukinfo_news_h1 = bukinfo_news_html.find("h1", class_='h3').text
    # bukovyna_news_h1 = bukovyna_news_html.find("h1", class_='title single').text
    # buknews_news_h1 = buknews_news_html.find("div", class_='news-page-text').find("h1").text
    #
    # acc_news_text = acc_news_html.find("div", class_='article-main-intro').text
    # bukpravda_news_text = bukpravda_news_html.find("span", class_='Apple-style-span').text
    # molbuk_news_text = molbuk_news_html.find("div", class_='shot-text').text
    # promin_news_text = promin_news_html.find("div", class_="post_content cf").text
    # tva_news_text = tva_news_html.find("div", class_='content-inner').text
    # pogliad_news_text = pogliad_news_html.find("div", class_='article-main-intro').text
    # # cvnews_news_text = cvnews_news_html.find("div", class_='post-text-container').find("strong").text
    # bukinfo_news_text = bukinfo_news_html.find("main", class_='news-item-content-body news-page-section').find(
    #     "span").text
    # bukovyna_news_text = bukovyna_news_html.find("article", class_='small single').find("p").text
    # buknews_news_text = buknews_news_html.find("div", style="text-align: justify;").text
    #
    # acc_img = acc_news_html.find("div", class_='pull-left item-image').find("img").get("src")
    # acc_news_img = f"https:{acc_img}"
    # molbuk_img = molbuk_news_html.find("div", class_='shot-text').find("img").get("src")
    # molbuk_news_img = f"https://molbuk.ua//{molbuk_img}"
    # promin_img = promin_news_html.find("div", class_="post_content cf").find("img").get("src")
    # promin_news_img = f"promin_img"
    # tva_img = tva_news_html.find("div", class_='entry-media').find("img").get("src")
    # tva_news_img = tva_img
    # pogliad_img = pogliad_news_html.find("div", class_='article-main-image').find("img").get("src")
    # pogliad_news_img = f"https:{pogliad_img}"
    # # cvnews_img = cvnews_news_html.find("div", class_='image-block').find("img").get("src")
    # # cvnews_news_img = cvnews_img
    # bukinfo_img = bukinfo_news_html.find("div", class_='image-slider-wrapper news-page-section').find("img") \
    #     .get("src")
    # bukinfo_news_img = bukinfo_img
    # bukovyna_img = bukovyna_news_html.find("article", class_='small single').find("img").get("src")
    # bukovyna_news_img = f"https://bukovyna.online/{bukovyna_img}"
    # buknews_img = buknews_news_html.find("img", class_='mainimage').get("src")
    # buknews_news_img = f"https:{buknews_img}"
    #
    # await bot.send_message(chat_id=news_bot_id, text=f'<b><a href="{bukpravda_link}">{bukpravda_news_h1}</a></b>\n'
    #                                                  f'<i>{bukpravda_news_text}</i>')
    #
    # for text, img in zip([{acc_link: [acc_news_h1, acc_news_text]},
    #                       {molbuk_link: [molbuk_news_h1, molbuk_news_text]},
    #                       {promin_link: [promin_news_h1, promin_news_text]},
    #                       {tva_link: [tva_news_h1, tva_news_text]},
    #                       {pogliad_link: [pogliad_news_h1, pogliad_news_text]},
    #                       # {cvnews_link: [cvnews_news_h1, cvnews_news_text]},
    #                       {bukinfo_link: [bukinfo_news_h1, bukinfo_news_text]},
    #                       {bukovyna_link: [bukovyna_news_h1, bukovyna_news_text]},
    #                       {buknews_link: [buknews_news_h1, buknews_news_text]}],
    #                      [acc_news_img, molbuk_news_img, promin_news_img, tva_news_img, pogliad_news_img,
    #                       bukinfo_news_img, bukovyna_news_img, buknews_news_img]):
    #     # cvnews_news_img, bukinfo_news_img, bukovyna_news_img, buknews_news_img]):
    #     # print(img)
    #     # print(list(text.keys())[0])
    #     # print((list(text.values())[0])[0])
    #     try:
    #         await bot.send_photo(chat_id=news_bot_id, photo=img,
    #                              caption=f'<b><a href="{list(text.keys())[0]}">{(list(text.values())[0])[0]}</a></b>\n\n'
    #                                      f'<i>{(list(text.values())[0])[1]}</i>')
    #         await asyncio.sleep(5)
    #     except Exception as e:
    #         await bot.send_message(chat_id="617710378", text=f'Новину не опубліковано, причина: {e}')
    #         print(e)
    #         continue
