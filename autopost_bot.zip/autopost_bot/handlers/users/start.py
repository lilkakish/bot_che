import threading

import aioschedule
from aiogram import types

from handlers.users.req import music_parsing, library_parsing, news_parsing, hackers_parsing, porn_quotes_parsing, \
    chernivtsi_news
from loader import dp, bot


async def scheduler():
    aioschedule.every(10).minutes.do(chernivtsi_news)
    while True:
        await aioschedule.run_pending()


t = threading.Thread(target=scheduler, name="тест")
t.start()


# @dp.message_handler(commands='start')
# async def start(message: types.Message):
#     # await music_parsing()
#     # await news_parsing()
#     # await hackers_parsing()
#     # await porn_quotes_parsing()
#     await chernivtsi_news()
