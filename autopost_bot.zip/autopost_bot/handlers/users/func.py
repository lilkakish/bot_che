# import fake_useragent
#
#
# def get_fake_user_agent():
#     user = fake_useragent.UserAgent().random
#     header = {
#         'user-agent': user
#     }
#     return header
#
#
# class Base:
#     def item_parsing(self):
#         pass
#
#     def get_item(self):
#         pass
#
#     @staticmethod
#     def send_item_to_channel(del_lines: int, name_txt: str):
#         with open(f'handlers/users/list_of_parsing/{name_txt}.txt', 'r', encoding='utf-8') as f:
#             lines = f.readlines()
#
#         with open(f'handlers/users/list_of_parsing/{name_txt}.txt', 'w', encoding='utf-8') as f:
#             f.writelines(lines[del_lines:])
#
#
# class Music(Base):
#     Base.get_item()
#
#
# class News(Base):
#     pass
#
#
# class HackNews(Base):
#     pass
#
#
# class Erotics(Base):
#     pass
#
#
# class Porn(Base):
#     pass
#
#
# class Memes(Base):
#     pass
#
#
# class LifeHacks(Base):
#     pass
